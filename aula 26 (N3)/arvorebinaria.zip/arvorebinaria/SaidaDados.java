package arvorebinaria;

public class SaidaDados {

	   static void imprimirEmOrdem(No no) {
	       if (no != null) {
	           imprimirEmOrdem(no.getEsquerda());
	           System.out.print(no.getValor() + " ");
	           imprimirEmOrdem(no.getDireita());
	       }
	   }
	}