package arvorebinaria;

public class Teste {


    public static void main(String[] args) {

        Main programa = new Main();

        No arvore = programa.criarArvore();


        SaidaDados.imprimirEmOrdem(arvore);

    }

}