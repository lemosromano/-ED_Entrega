package arvorebinaria;

public class No {

	   private int valor;
	   private No direita;
	   private No esquerda;

	   public No(int valor) {
	       this.valor = valor;
	       this.direita = null;
	       this.esquerda = null;
	   }

	   public int getValor() {
	       return valor;
	   }

	   public No getDireita() {
	       return direita;
	   }

	   public No getEsquerda() {
	       return esquerda;
	   }

	   public void setDireita(No direita) {
	       this.direita = direita;
	   }

	   public void setEsquerda(No esquerda) {
	       this.esquerda = esquerda;
	   }
	}