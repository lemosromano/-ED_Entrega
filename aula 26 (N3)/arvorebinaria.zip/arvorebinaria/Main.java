package arvorebinaria;

import javax.swing.JOptionPane;

public class Main {

   static int obterValorNo() {
       String entrada = JOptionPane.showInputDialog(null, "Digite o valor do nó");
       int valor = 0;
       try {
           valor = Integer.parseInt(entrada);
       } catch (Exception e) {
           JOptionPane.showMessageDialog(null, "Não foi possível converter \n" + e + "");
           return obterValorNo();
       }
       return valor;
   }

   static No criarArvore() {
       int valor = obterValorNo();
       No no = new No(valor);

       criarNoFilho(no, "esquerda");
       criarNoFilho(no, "direita");

       if (no.getEsquerda() == null) {
           no.setEsquerda(no.getDireita());
           no.setDireita(null);
       }

       ordenarFilhos(no);

       return no;
   }

   private static void criarNoFilho(No no, String direcao) {
       int confirmacao = JOptionPane.showConfirmDialog(null, "Deseja criar o nó à " + direcao + "?",
               direcao.substring(0, 1).toUpperCase() + direcao.substring(1) + ", Nó principal: " + no.getValor(), JOptionPane.YES_NO_OPTION);

       if (confirmacao == JOptionPane.YES_OPTION) {
           No filho = criarArvore();
           if (direcao.equals("esquerda")) {
               no.setEsquerda(filho);
           } else {
               no.setDireita(filho);
           }
       } else {
           if (direcao.equals("esquerda")) {
               no.setEsquerda(null);
           } else {
               no.setDireita(null);
           }
       }
   }

   private static void ordenarFilhos(No no) {
       No esquerda = no.getEsquerda();
       No direita = no.getDireita();

       int valorEsquerda = esquerda != null ? esquerda.getValor() : 0;
       int valorDireita = direita != null ? direita.getValor() : 0;

       if (valorEsquerda > valorDireita) {
           no.setEsquerda(direita);
           no.setDireita(esquerda);
       }
   }

   public static void main(String[] args) {
       Main programa = new Main();
       No arvore = programa.criarArvore();

       SaidaDados.imprimirEmOrdem(arvore);
   }
}